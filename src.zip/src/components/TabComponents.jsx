import GoogleAds from "../pages/GoogleAds";
import GoogleAnalytics from "../pages/GoogleAnalytics";
// import IntentInsights from "../pages/IntentInsights";

const TabComponents = {
  "Google Ads Campaigns": GoogleAds,
  "Google Analytics": GoogleAnalytics,
//   "Intent Insights": IntentInsights,
};
